define([
    'ko',
    'jquery',
    'api',
    'mapbox',
    'leaflet-cluster'
], function (ko, $, api) {
    L.mapbox.accessToken = 'pk.eyJ1Ijoic2ltb25sZXZhc3NldXIiLCJhIjoibUhvemVUOCJ9.e3N27kVBomXW5ohV2tK1Hg';

    /**********************/
    /***** KO BINDING *****/
    /**********************/
    ko.bindingHandlers.geoMap = {
        init: function (element, valueAccessor, allBindingsAccessor, viewModel, context) {
            var options = ko.unwrap(valueAccessor()),
                map = L.mapbox.map(element, 'simonlevasseur.k9pg7od8', { minZoom: 2, maxZoom: 19, maxBounds: new L.LatLngBounds([-90,-180], [90, 180]) }),
                $map = $(element).addClass('koGeo');

            $map.on('click', function (e) {
                e.stopPropagation();
            });

            if (options.location) {
                map.setView(options.location, 8);
            }

            var locationsCluster = new L.MarkerClusterGroup({
                showCoverageOnHover: false,
                iconCreateFunction: function(cluster) {
                    return new L.DivIcon({
                        html: cluster.getChildCount(),
                        className: 'map-icon map-cluster'
                    });
                }
            }).addTo(map);

            var devicesCluster = new L.MarkerClusterGroup({
                showCoverageOnHover: false,
                iconCreateFunction: function(cluster) {
                    var markers = cluster.getAllChildMarkers(),
                        hasAlerts = ko.utils.arrayFirst(markers, function (marker) {
                            if (marker.options.icon.options.className.indexOf('map-alert') !== -1) {
                                return true;
                            }
                        }),
                        classes = hasAlerts ? ' map-alert' : '';

                    return new L.DivIcon({
                        html: cluster.getChildCount(),
                        className: 'map-icon map-cluster' + classes
                    });
                }
            }).addTo(map);

            // Populate locations
            api.locations.get().done(function (locations) {
                ko.utils.arrayForEach(locations, function (location) {
                    L.marker([location.Latitude, location.Longitude], { icon: new L.DivIcon({ className: 'map-icon map-building', iconSize: [30, 30], popupAnchor: [0, -15] }) })
                        .bindPopup('<div>' + location.Name + '</div>')
                        .addTo(locationsCluster);
                });
            });

            // Populate devices
            api.devices.getExtra().done(function (devices) {
                ko.utils.arrayForEach(devices, function (device) {
                    if (!device.Patient) {
                        return;
                    }
                    var classes = 'map-icon';
                    if (device.Alerts.length) { classes += ' map-alert' }
                    var marker = L.marker([device.Latitude, device.Longitude], { icon: new L.DivIcon({ className: classes, iconSize: [30, 30], popupAnchor: [0, -15] }) })
                        .bindPopup('<div class="map-patient-name">' + device.Patient.Name + '</div><div class="map-patient-alerts">' + device.Alerts.length + ' Alerts</div><a href="#map/device/' + device.Patient.Id + '" id="test">Click to view more...</a>')
                        .addTo(devicesCluster);
                });
            });

            /******************/
            /**** DISPOSAL ****/
            /******************/
            ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
                // Remove map and all of its handlers
                map.remove();
            });
        }
    };
});