define([
  'ko',
  'jquery'
], function (ko, $) {
    'use strict';

    /***************************/
    /***** KO.LOCALIZATION *****/
    /***************************/
    ko.localization = {
        current: ko.observable(), // Track current language setting
        data: ko.observable({}), // Current language data object
        default: 'en', // Default language in case we don't support the user's language
        supported: ['en', 'fr'], // List of supported languages
        loaded: [], // Array of previously loaded languages to prevent double loads
        localize: function (key) { // Get translation string
            var data = this.data();

            // Only if object isn't empty
            return !$.isEmptyObject(data) && getProp(data, key);
        },
        getLocalization: function (key) { // Get translation computed so updates are sent
            return ko.computed(function () {
                return ko.localization.localize(key);
            });
        },
        set: function (l) { // Method to change the language
            var lang = l;

            // If language isn't supported then use the default
            if (this.supported.indexOf(lang) === -1) {
                lang = this.default;
            }

            // Attempt to find the data file if it's already been loaded
            var alreadyLoaded = ko.utils.arrayFirst(this.loaded, function (l) {
                return l.lang === lang;
            });

            if (!alreadyLoaded) { // File hasn't been loaded yet
                $.ajax({
                    url: 'localizations/' + lang + '.json',
                    dataType: 'json'
                }).done(function (data) {
                    // Only set the language in local storage if the user changed it manually
                    if (this.current()) {
                        localStorage.setItem('lang', lang);
                    }
                    this.loaded.push({ lang: lang, data: data });
                    this.data(data);
                    this.current(lang);
                }.bind(this));
            } else {
                // Only set the language in local storage if the user changed it manually
                if (this.current()) {
                    localStorage.setItem('lang', lang);
                }
                this.data(alreadyLoaded.data);
                this.current(lang);
            }
        }
    };

    // Set language based on: LocalStorage || System Language || Browser Language
    var lang = localStorage.getItem('lang') || window.navigator.userLanguage || window.navigator.language;
    // We only care about the first 2 letters of the language
    ko.localization.set(lang.substr(0, 2));


    /***********************/
    /***** KO BINDINGS *****/
    /***********************/
    ko.bindingHandlers.localize = {
        update: function (element, valueAccessor, allBindingsAccessor, viewModel, context) {
            var key = ko.utils.unwrapObservable(valueAccessor());

            ko.localization.current(); // Trigger updates if lang changes
            ko.localization.data();

            if (ko.localization.current() && Object.prototype.toString.call(key) === '[object String]') {
                // Get value for key
                var value = ko.localization.localize(key);

                // No value found so log an error but continue execution
                if (!value) {
                    console.log('Could not find localization for: ' + key);
                    return;
                }

                // Update the text binding with the value
                ko.bindingHandlers.html.update(element, function () { return value; });
            }
        }
    };

    /*****************************/
    /***** PRIVATE FUNCTIONS *****/
    /*****************************/
    function getProp(obj, value) {
        var path = value.split('.');
        var obj = obj;

        ko.utils.arrayForEach(path, function (val) {
            if (obj) {
                obj = obj[val];
            }
        });

        return obj;
    }
});