require([
    'ko',
    'routie',
    'api',
    'components',
    'koLocalization'
], function (ko, routie, api) {
    'use strict';

    var vm = {
        currentPage: ko.observable(),
        currentPageParams: ko.observable(),
        showMenu: ko.observable(false),
        toggleMenu: function () {
            vm.showMenu(!vm.showMenu());
        },
        hasAlerts: ko.observable(false)
    };

    setInterval(function () {
        api.alerts.get().done(function (alerts) {
            var hasAlert = ko.utils.arrayFirst(alerts, function (alert) {
                if (alert.Status < 3) {
                    return true;
                }
            });

            vm.hasAlerts(hasAlert);
        });
    }, 1800);

    // Wrap the params observable in a computed to trick the component binding
    vm.currentPageParamsHelper = ko.computed(function () {
        return vm.currentPageParams;
    });

    routie({
        'map/device/:id': function(id) {
            vm.currentPage('page-map');
            vm.currentPageParams({ patientId: id });
        },
        'map': function() {
            vm.currentPage('page-map');
            vm.currentPageParams({});
        },
        'alerts': function() {
            vm.currentPage('page-alerts');
            vm.currentPageParams({});
        },
        'patients/:id': function(id) {
            vm.currentPage('page-patients');
            vm.currentPageParams({ pageId: id });
        },
        'patients': function() {
            vm.currentPage('page-patients');
            vm.currentPageParams({});
        },
        '*': function(arg) {
            routie('map');
        }
    });

    ko.applyBindings(vm, document.getElementById('htmlTop'));
});