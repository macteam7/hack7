define([
    'ko',
    'text!../../templates/page-map.html',
    'api',
    'dialog',
    'koGeoMap'
], function (ko, htmlString, api, dialog) {
    function PageMapVM(params) {
        this.subs = [];
        this.listenForRoutes(params);
    }

    PageMapVM.prototype.dispose = function () {
        while(this.subs.length) {
            this.subs.pop().dispose();
        }
    };

    PageMapVM.prototype.listenForRoutes = function (params) {
        this.subs.push(ko.computed(function () {
            this.onLoad(params);
        }, this));
    };

    PageMapVM.prototype.onLoad = function (params) {
        var val = params();
        if (val && val.patientId) {
            require(['text!../../templates/patient.html'], function (templ) {
                api.patients.getPatient(val.patientId).done(function (patient) {
                    var d = dialog.modal({
                        content: templ,
                        onHide: function () {
                            routie('map');
                        }
                    });

                    ko.applyBindingsToDescendants(patient, d.$el[0]);
                });
            });
        }
    };

    return { viewModel: PageMapVM, template: htmlString };
});