define([
    'ko',
    'text!../../templates/page-alerts.html',
    'api',
    'koGeoMap'
], function (ko, htmlString, api) {
    function PageAlertsVM() {
        this.alerts = ko.observableArray([]);
        this.selectedAlert = ko.observable();

        var self = this;
        this.getAlerts();
        setInterval(function () {
            self.getAlerts();
        }, 10000);
    }

    PageAlertsVM.prototype.acknoledgeAlert = function (alert, e) {
        if (alert.Status === 1) {
            alert.Status = 2;

            var self = this;
            api.alerts.update(alert).done(function () {
                var temp = self.alerts();
                self.alerts([]);
                self.alerts(temp);
            });
        }

        e.stopPropagation();
    };

    PageAlertsVM.prototype.dismissAlert = function (alert) {
        alert.status = 'Processed';

        var temp = this.alerts();
        this.alerts([]);
        this.alerts(temp);
    };

    PageAlertsVM.prototype.getAlerts = function () {
        var self = this;
        var temp = [];
        api.alerts.get().done(function (alerts) {
            ko.utils.arrayForEach(alerts, function (alert) {
                if (alert.PatientId && alert.Status !== 3) {
                    alert.name = 'Jenny';
                    temp.push(alert);
                }
            });
            self.alerts(temp);
        });
    };

    PageAlertsVM.prototype.toggleSelection = function (alert) {
        if (this.selectedAlert() === alert) {
            this.selectedAlert(null);
        } else {
            this.selectedAlert(alert);
        }
    };

    return { viewModel: PageAlertsVM, template: htmlString };
});