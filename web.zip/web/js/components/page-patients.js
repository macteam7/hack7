define([
    'ko',
    'text!../../templates/page-patients.html',
    'dialog',
    'api',
    'routie'
], function (ko, htmlString, dialog, api, routie) {
    function PagePatientsVM(params) {
        this.subs = [];
        this.listenForRoutes(params);

        this.patients = ko.observableArray([]);
        this.searchTerm = ko.observable().extend({ rateLimit: { method: "notifyWhenChangesStop", timeout: 400 } });

        this.searchTerm.subscribe(function (val) {
            var self = this;

            // if the search term is empty, get all the patients
            if (val === '') {
                api.patients.get().done(function (patients) { self.onGetDone(patients); });
            }
            else {
                api.patients.search(val).done(function (patients) { self.onGetDone(patients); });
            }
        }, this);
    }

    PagePatientsVM.prototype.dispose = function () {
        while(this.subs.length) {
            this.subs.pop().dispose();
        }
    };

    PagePatientsVM.prototype.viewPatient = function (patient) {
        routie('patients/' + patient.Id);
    };

    PagePatientsVM.prototype.listenForRoutes = function (params) {
        this.subs.push(ko.computed(function () {
            this.onLoad(params);
        }, this));
    };

    PagePatientsVM.prototype.onGetDone = function (patients) {
        this.patients.removeAll();
        this.patients(patients);
    }

    PagePatientsVM.prototype.onLoad = function (params) {
        var val = params();
        if (val && val.pageId) {
            require(['text!../../templates/patient.html'], function (templ) {
                api.patients.getPatient(val.pageId).done(function (patient) {
                    var d = dialog.modal({
                        content: templ,
                        onHide: function () {
                            routie('patients');
                        }
                    });

                    ko.applyBindingsToDescendants(patient, d.$el[0]);
                });
            });
        }

        var self = this;

        if (this.searchTerm && this.searchTerm() && this.searchTerm() !== '') {
            api.patients.search(this.searchTerm()).done(function (patients) { self.onGetDone(patients); });
        } else {
            api.patients.get().done(function (patients) { self.onGetDone(patients); });
        }
    };

    return { viewModel: PagePatientsVM, template: htmlString };
});