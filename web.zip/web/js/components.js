define([
    'ko',
    'text'
], function (ko) {
    ko.components.register('page-map', { require: 'components/page-map' });
    ko.components.register('page-alerts', { require: 'components/page-alerts' });
    ko.components.register('page-patients', { require: 'components/page-patients' });
    ko.components.register('primary-nav', { template: { require: 'text!../templates/primary-nav.html' } });
});