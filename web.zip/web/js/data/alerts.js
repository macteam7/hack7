define([
    'jquery'
], function ($) {
    function AlertsApi() {}

    AlertsApi.prototype.get = function() {
        return $.ajax({
            url: "http://machack7api.cloudapp.net/api/alerts"
        });
    };

    AlertsApi.prototype.getExtra = function() {
        return $.ajax({
            url: "http://machack7api.cloudapp.net/api/alerts/extra"
        });
    };

    AlertsApi.prototype.update = function(alert) {
        return $.ajax({
            type: "POST",
            dataType: "json",
            data: alert,
            url: "http://machack7api.cloudapp.net/api/alerts/update/" + alert.RowKey
        });
    };

    return AlertsApi;
});
