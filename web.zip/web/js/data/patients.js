define([
    'jquery'
], function ($) {
    function PatientsApi() {}

    PatientsApi.prototype.get = function() {
        return $.ajax({
            url: "http://machack7api.cloudapp.net/api/patients"
        });
    };

    PatientsApi.prototype.getPatient = function(id) {
        return $.ajax({
            url: "http://machack7api.cloudapp.net/api/patients/id/" + id
        });
    };

    PatientsApi.prototype.search = function(name) {
        return $.ajax({
            url: "http://machack7api.cloudapp.net/api/patients/name/" + name
        });
    };

    return PatientsApi;
});
