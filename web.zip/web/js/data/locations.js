define([
    'jquery'
], function ($) {
    function LocationsApi() {}

    LocationsApi.prototype.get = function() {
        return $.ajax({
            url: "http://machack7api.cloudapp.net/api/locations"
        });
    };

    return LocationsApi;
});