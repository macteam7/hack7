define([
    'AlertsApi',
    'DevicesApi',
    'LocationsApi',
    'PatientsApi'
], function (AlertsApi, DevicesApi, LocationsApi, PatientsApi) {
    return {
        alerts: new AlertsApi(),
        devices: new DevicesApi(),
        locations: new LocationsApi(),
        patients: new PatientsApi()
    };
});