define([
    'jquery'
], function ($) {
    function DevicesApi() {}

    DevicesApi.prototype.get = function() {
        return $.ajax({
            url: "http://machack7api.cloudapp.net/api/devices"
        });
    };

    DevicesApi.prototype.getExtra = function() {
        return $.ajax({
            url: "http://machack7api.cloudapp.net/api/devices/extra"
        });
    };

    return DevicesApi;
});
