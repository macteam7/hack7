var require = {
    paths: {
        // Vendor
        'ko': 'vendor/knockout-3.2.0.min',
        'jquery': 'vendor/jquery-2.1.1.min',
        'routie': 'vendor/routie-0.3.2.min',
        'text': 'vendor/text-2.0.12.min',
        'mapbox': 'vendor/mapbox-2.1.4.min',
        'dialog': 'vendor/dialog',
        'leaflet-cluster': 'vendor/leaflet.markercluster-0.4.0-min',

        // User
        'components': 'components',

        // Bindings
        'koGeoMap': 'bindings/koGeoMap',
        'koLocalization': 'bindings/koLocalization',

        // Data
        'api': 'data/api',
        'AlertsApi': 'data/alerts',
        'DevicesApi': 'data/devices',
        'LocationsApi': 'data/locations',
        'PatientsApi': 'data/patients'
    },
    shim: {
        'ko': {
            deps: ['jquery']
        },
        'routie': {
            exports: 'routie'
        },
        'leaflet-cluster': {
            deps: ['mapbox']
        }
    }
};